<?php
  require_once("../../../wp-load.php");
  global $wpdb;
  $PGPath=plugins_url()."/exitpopup/";
  include('checkvalid.php');
  
  
  $exitpopup_ResetTime=$_POST['exitpopup_ResetTime'];
  $exitpopup_AddToEvery=$_POST['exitpopup_AddToEvery'];
  
  
  update_option( 'exitpopup_ResetTime', $exitpopup_ResetTime );
  update_option( 'exitpopup_AddToEvery', $exitpopup_AddToEvery );
  
  
  //header('location: '.admin_url().'admin.php?page=exitpopup');
   
?>
<script type="text/javascript">
 window.location='<?php echo admin_url()."admin.php?page=exitpopup"; ?>';
</script>