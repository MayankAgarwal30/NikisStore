<?php
/*
Plugin Name:  Exit Popup wp
Plugin URI: http://www.pluginexpert.com/
Description: Capture bounce traffic before they leave your site
Version: 1.00
Author: pluginexpert
Author URI: http://www.pluginexpert.com/
*/

require_once(ABSPATH . 'wp-settings.php');
error_reporting(0);

register_activation_hook(__FILE__,'exitpopup_install');

function exitpopup_install() {
	global $wpdb;
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

	add_option("exitpopup_ResetTime", '', '', 'yes');
	add_option("exitpopup_AddToEvery", '', '', 'yes'); 
	include('create_database.php');
}

if ( is_admin() ){
	/* Call the html code */
	add_action('admin_menu', 'exitpopup_admin_menu');
	function exitpopup_admin_menu() {
	add_menu_page('Exit Popup', 'Exit Popup', 'administrator','exitpopup', 'exitpopup_admin');
	}
}

function exitpopup_admin() { 
	global $wpdb; 
	
	$PGPath=plugins_url()."/exitpopup/";
	//wp_deregister_script( 'jquery' );
	 
	wp_register_script('exp_jq', '//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js'); 
	wp_enqueue_script('exp_jq');
	wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
	wp_enqueue_style('thickbox');	
	wp_enqueue_style( 'exp_backstyle', $PGPath . 'css/backend_style.css' );	
	wp_enqueue_style( 'wp-color-picker' );	
	wp_enqueue_script( 'exp_backscript_color', $PGPath . 'js/backend_script.js', array( 'wp-color-picker' ), false, true ); 
	include('main.php');
} 

//wp_deregister_script( 'jquery' );
wp_register_script('exp_jq', '//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js');
wp_enqueue_script('exp_jq'); 

$exitpopup_AddToEvery=get_option('exitpopup_AddToEvery');
$exitpopup_ResetTime=get_option('exitpopup_ResetTime');

//$exitpopup="0";
if ($exitpopup_AddToEvery!="1"){
	//echo "<h1>--$exitpopup_AddToEvery--</h1>";
	add_shortcode('exitpopup', 'exitpopup_add' );
}else{ 
	if (!is_admin() ){
	global $wpdb;
	$PGPath=plugins_url()."/exitpopup/";
	$exp_id=$exitpopup_AddToEvery;
	include('showexitpopup.php');
	}  
}               
 
function exitpopup_add($atts){
	global $wpdb;
	$PGPath=plugins_url()."/exitpopup/";
	$exp_id=$atts['id'];
	$exitpopup_AddToEvery=get_option('exitpopup_AddToEvery');
	$exitpopup_ResetTime=get_option('exitpopup_ResetTime');
	include('showexitpopup.php');
} 
                             
?>