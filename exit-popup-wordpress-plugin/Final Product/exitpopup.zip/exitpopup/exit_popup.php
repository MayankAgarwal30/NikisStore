<div class="exp_table_wrapper">
	<a href="admin.php?page=exitpopup&amp;s=nb" class="exp_button">Create New</a>
</div>

<table class="exp_table">
 <tr>
  <td><b>Exit popup Name</b></td><td><b>Short Code</b></td><td><b>Options</b></td>
 </tr>
 <tr>
  <td colspan="5" height="20"></td>
 </tr>
  
 <?php
  $Table=$wpdb->prefix . "exitpopup_tbl";
  //$re=mysql_query(" SELECT * FROM $Table ");
  //while ($ro=mysql_fetch_assoc($re)){ 
  $Results1 = $wpdb->get_results( "SELECT * FROM $Table ");
  foreach ( $Results1 as $ro ){
					 //print_r($ro);
					 $array = json_decode(json_encode($ro), True);
					 extract($array);
					 
					 $exp_name=stripslashes($exp_name);
					 $Options="<img title='Edit this exitpopup' src='$PGPath"."images/edit1.png' style='cursor:pointer; width:24px;' onclick=\"window.location='index.php?page=exitpopup&s=e&b=$exp_id';\">&nbsp;";
					 $Options.="<img title='Delete this exitpopup' src='$PGPath"."images/delete1.png' style='cursor:pointer; width:24px;' onclick=\"deleteBnce('$exp_id');\">&nbsp;";
					 $Options.="<img title='Stats' src='$PGPath"."images/status.png' style='cursor:pointer; width:24px;' onclick=\"window.location='index.php?page=exitpopup&s=st&b=$exp_id';\">";
					 
					 echo "
						   <tr>
							<td>$exp_name</td>
							<td>[exitpopup id='$exp_id']</td>
							<td>$Options</td>
						   </tr> 
						  ";
               }
 ?>
</table>
<script type='text/javascript'>
function deleteBnce(b){
			var C=confirm('Are you sure you want to delete this exitpopup ?');
			if (C===true){
						  window.location='<?php echo $PGPath; ?>delete.php?b='+b;
						 }else{
							   return false;
							  }
        }
</script>                       