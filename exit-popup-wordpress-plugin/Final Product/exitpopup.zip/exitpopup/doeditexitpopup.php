<?php
 
 require_once("../../../wp-load.php");
 global $wpdb;
 include('checkvalid.php');
 
 $PGPath=plugins_url()."/exitpopup/";
 $Table = $wpdb->prefix . "exitpopup_tbl";
 
 $exp_name=$_POST['exp_name'];
 $exp_title=$_POST['exp_title'];
 $exp_description=$_POST['exp_description'];
 $exp_image=$_POST['exp_image'];
 $exp_button_text=$_POST['exp_button_text'];
 $exp_button_url=$_POST['exp_button_url'];
 $exp_button_color=$_POST['exp_button_color'];
 $exp_button_text_color=$_POST['exp_button_text_color'];
 $exp_border_color=$_POST['exp_border_color'];
 $exp_overlay_color=$_POST['exp_overlay_color'];
  
 
 $B=$_POST['B'];
 $B=(int)$B;
 



 $wpdb->update( $Table, 
	 array( 
			 'exp_name' => $exp_name,	
			 'exp_title' => $exp_title,
			 'exp_description' => $exp_description,
			 'exp_image' => $exp_image,
			 'exp_button_text' => $exp_button_text,
			 'exp_button_url' => $exp_button_url,
			 'exp_button_color' => $exp_button_color,
			 'exp_button_text_color' => $exp_button_text_color,
			 'exp_border_color' => $exp_border_color,
			 'exp_overlay_color' => $exp_overlay_color
	 ), 
 array( 'exp_id' => $B ));
                       
                                                
 header('location: '.admin_url().'admin.php?page=exitpopup');
?>