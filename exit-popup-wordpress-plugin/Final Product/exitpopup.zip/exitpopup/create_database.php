<?php

$table_name = $wpdb->prefix . "exitpopup_tbl";
  //drop the exiting table if there is one
  //$sql="DROP TABLE $table_name"; 
  //$wpdb->query( $sql );                                                                                        
  $sql = "CREATE TABLE IF NOT EXISTS $table_name (
  `exp_id` int(7) NOT NULL AUTO_INCREMENT,
  `exp_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,  
  `exp_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exp_description` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `exp_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exp_button_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exp_button_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exp_button_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exp_button_text_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exp_border_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,  
  `exp_overlay_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,  
  UNIQUE KEY exp_id (exp_id)

  )"; 
 dbDelta( $sql );
   
$table_name = $wpdb->prefix . "exitpopup_hits"; 
  //drop the exiting table if there is one
  //$sql="DROP TABLE $table_name";
  //$wpdb->query( $sql );                                                                                       
  $sql = "CREATE TABLE IF NOT EXISTS $table_name (
  `H_ID` int(7) NOT NULL AUTO_INCREMENT,
  `ForBounce` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DateX` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY H_ID (H_ID)
  )";
 dbDelta( $sql );                                  

?>