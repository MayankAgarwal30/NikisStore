<?php
 require_once("../../../wp-load.php");
 global $wpdb;
 $B=$_POST['B'];
 $DateX=date('m/d/Y');
 $Table = $wpdb->prefix . "exitpopup_hits";
 $wpdb->insert( $Table, array( 'ForBounce' => $B, 'DateX' => $DateX ));
 //$T=mktime().time()+60*60*24*$exitpopup_ResetTime;
 
?>