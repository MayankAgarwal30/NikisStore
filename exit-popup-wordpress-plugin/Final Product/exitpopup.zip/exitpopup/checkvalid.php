<?php
 $correct=site_url(); 
  $actual=$_SERVER["HTTP_REFERER"];
  $stopit=true;
if (strpos($actual, $correct) !== false) {
	$stopit=false;
 }

if (!is_user_logged_in()){
$stopit=true;
}

if ($stopit){exit();}
?>