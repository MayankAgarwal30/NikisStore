<?php
 $B=$_GET['b'];
 $PGPath=plugins_url()."/exitpopup/";
 
 $re=" SELECT * FROM ".$wpdb->prefix . "exitpopup_tbl WHERE exp_id='$B' ";
 $row = $wpdb -> get_results($re);
 foreach( $row as $rows ) {
                           $exitpopupName=$rows->exp_name;
                          } 
  
 $re=" SELECT * FROM ".$wpdb->prefix . "exitpopup_hits WHERE ForBounce='$B' ";
 $row = $wpdb -> get_results($re);
 $LifeTimeHits = count($row);
 
 $DateX=date('m/d/Y');
 $re=" SELECT * FROM ".$wpdb->prefix . "exitpopup_hits WHERE ForBounce='$B' AND DateX='$DateX' ";
 $row = $wpdb -> get_results($re);
 $TodaysHits = count($row);
 
 
 $m= date("m"); // Month value
 $de= date("d"); //today's date
 $y= date("Y"); // Year value
 $DateX1=date('m/d/Y', mktime(0,0,0,$m,($de-1),$y));
 $re=" SELECT * FROM ".$wpdb->prefix . "exitpopup_hits WHERE ForBounce='$B' AND DateX='$DateX1' ";
 $row = $wpdb -> get_results($re);
 $Hits1 = count($row); 
 
 $m= date("m"); // Month value
 $de= date("d"); //today's date
 $y= date("Y"); // Year value
 $DateX1=date('m/d/Y', mktime(0,0,0,$m,($de-2),$y));
 $re=" SELECT * FROM ".$wpdb->prefix . "exitpopup_hits WHERE ForBounce='$B' AND DateX='$DateX1' ";
 $row = $wpdb -> get_results($re);
 $Hits2 = count($row);
 
 $m= date("m"); // Month value
 $de= date("d"); //today's date
 $y= date("Y"); // Year value
 $DateX1=date('m/d/Y', mktime(0,0,0,$m,($de-3),$y));
 $re=" SELECT * FROM ".$wpdb->prefix . "exitpopup_hits WHERE ForBounce='$B' AND DateX='$DateX1' ";
 $row = $wpdb -> get_results($re);
 $Hits3 = count($row);
 
 $m= date("m"); // Month value
 $de= date("d"); //today's date
 $y= date("Y"); // Year value
 $DateX1=date('m/d/Y', mktime(0,0,0,$m,($de-4),$y));
 $re=" SELECT * FROM ".$wpdb->prefix . "exitpopup_hits WHERE ForBounce='$B' AND DateX='$DateX1' ";
 $row = $wpdb -> get_results($re);
 $Hits4 = count($row);
?>

<table class="exp_state_table" style="font-size:16px; font-weight:900;">
 <tr>
  <td colspan="2">Stats for: <?php echo $exitpopupName; ?></td>
 </tr>
 <tr><td colspan="2" height="15"></td></tr>
 <tr><td>Lifetime Exit popup Redirects: </td><td><?php echo $LifeTimeHits; ?></td></tr>
</table>  

<br>Today:<br>
<div class="exp_state current" style='border-radius: 0px 10px 10px 0px; box-shadow: 3px 3px 2px #000000; background-image:url(<?php echo $PGPath; ?>images/texture1.png); position:relative; width:<?php echo round(800*($TodaysHits/$LifeTimeHits)); ?>px; min-width:30px; height:30px; background-color:#990000;'>
 <div style='position:absolute; top:4px; left:5px;'><font style='font-size:24px; font-weight:900; color:#ffffff; padding-top:8px;'><?php echo $TodaysHits; ?></font></div>
</div>

<br>Yesterday:<br> 
<div class="exp_state yesterday" style='border-radius: 0px 10px 10px 0px; box-shadow: 3px 3px 2px #000000; background-image:url(<?php echo $PGPath; ?>images/texture1.png); position:relative; width:<?php echo round(800*($Hits1/$LifeTimeHits)); ?>px; min-width:30px; height:30px; background-color:#009900;'>
 <div style='position:absolute; top:4px; left:5px;'><font style='font-size:24px; font-weight:900; color:#ffffff; padding-top:8px;'><?php echo $Hits1; ?></font></div>
</div> 
 
<br>Two days ago:<br>
<div class="exp_state twoday_ago" style='border-radius: 0px 10px 10px 0px; box-shadow: 3px 3px 2px #000000; background-image:url(<?php echo $PGPath; ?>images/texture1.png); position:relative; width:<?php echo round(800*($Hits2/$LifeTimeHits)); ?>px; min-width:30px; height:30px; background-color:#000099;'>
 <div style='position:absolute; top:4px; left:5px;'><font style='font-size:24px; font-weight:900; color:#ffffff; padding-top:8px;'><?php echo $Hits2; ?></font></div>
</div>

<br>Three days ago:<br>
<div "exp_state threeday_ago" style='border-radius: 0px 10px 10px 0px; box-shadow: 3px 3px 2px #000000; background-image:url(<?php echo $PGPath; ?>images/texture1.png); position:relative; width:<?php echo round(800*($Hits3/$LifeTimeHits)); ?>px; min-width:30px; height:30px; background-color:#909090;'>
 <div style='position:absolute; top:4px; left:5px;'><font style='font-size:24px; font-weight:900; color:#ffffff; padding-top:8px;'><?php echo $Hits3; ?></font></div>
</div>

<br>Four days ago<br>
<div "exp_state fourday_ago" style='border-radius: 0px 10px 10px 0px; box-shadow: 3px 3px 2px #000000; background-image:url(<?php echo $PGPath; ?>images/texture1.png); position:relative; width:<?php echo round(800*($Hits4/$LifeTimeHits)); ?>px; min-width:30px; height:30px; background-color:#990990;'> 
 <div style='position:absolute; top:4px; left:5px;'><font style='font-size:24px; font-weight:900; color:#ffffff; padding-top:8px;'><?php echo $Hits4; ?></font></div>
</div>


