<?php
 include('confirm.php');
 $Table = $wpdb->prefix . "exitpopup_tbl";
 $B=$_GET['b'];
 $Results1 = $wpdb->get_results( " SELECT * FROM $Table WHERE exp_id='$B' ");
 foreach ( $Results1 as $ro ){
			 //print_r($ro);
			 $array = json_decode(json_encode($ro), True);
			 extract($array);
	 }        
                       
?> 

<div class="exp_create_section">
	<div class="exp_create_wrapper">
		<h2 class="exp_heading">Edit Exit Popup</h2>
		<span style="color:red;">* empty fields will not appear on popup</span>
	</div>
	
<form class="exp_create_form" method="post" action="<?php echo $PGPath; ?>doeditexitpopup.php" onsubmit="return checkForm();">
<input type="hidden" name="B" value="<?php echo $B; ?>">
	<div class="exp_form_field">
		<label>Popup Name: </label>
		<div class="exp_form_content"><input type="text" style="width:400px;" name="exp_name" id="exp_name" value="<?php echo stripslashes($exp_name); ?>"></div>
	</div>
	
	<div class="exp_form_field">
		<label>Title: </label>
		<div class="exp_form_content"><input type="text" style="width:400px;" name="exp_title" id="exp_title" value="<?php echo stripslashes($exp_title); ?>"></div>
	</div>
	
	<div class="exp_form_field">
		<label>Description: </label>
		<div class="exp_form_content"><input type="text" style="width:400px;" name="exp_description" id="exp_description" value="<?php echo stripslashes($exp_description); ?>"></div>
	</div>	
  
    <div class="exp_form_field">
		<label>Image: </label>
		<div class="exp_form_content"><input type="text" style="width:400px;" name="exp_image" id="exp_image" value="<?php echo stripslashes($exp_image); ?>"><button class="exp_button exp_upload_image_button">Upload</button></div>
	</div>
	
	<div class="exp_form_field">
		<label>Button Text : </label>
		<div class="exp_form_content"><input type="text" style="width:400px;" name="exp_button_text" id="exp_button_text" value="<?php echo stripslashes($exp_button_text); ?>"></div>
	</div>
	 
	<div class="exp_form_field">
		<label>Button Url : </label>
		<div class="exp_form_content"><input type="text" style="width:400px;" name="exp_button_url" id="exp_button_url" value="<?php echo stripslashes($exp_button_url); ?>"></div>
	</div>
	
	<div class="exp_form_field"> 
		<label>Button Background Color : </label>
		<div class="exp_form_content"><input type="text" style="width:400px;" name="exp_button_color" value="<?php echo stripslashes($exp_button_color); ?>" id="exp_button_color" class="exp_color"></div>
	</div>
	
	<div class="exp_form_field">
		<label>Button Text Color : </label>
		<div class="exp_form_content"><input type="text" style="width:400px;" name="exp_button_text_color" value="<?php echo stripslashes($exp_button_text_color); ?>" id="exp_button_text_color" class="exp_color"></div>
	</div>
	 
	<div class="exp_form_field">
		<label>Border Color : </label>
		<div class="exp_form_content"><input type="text" style="width:400px;" name="exp_border_color" id="exp_border_color" value="<?php echo stripslashes($exp_border_color); ?>" class="exp_color"></div>
	</div>
	
	<div class="exp_form_field">
		<label>Overlay Color : </label>
		<div class="exp_form_content"><input type="text" style="width:400px;" name="exp_overlay_color" id="exp_overlay_color" value="<?php echo stripslashes($exp_overlay_color); ?>" class="exp_color"></div>
	</div>
  
  <div class="exp_form_field">
   <div class="exp_btn_wrapper"><input type="submit" value="Save"></div>
  </div>
</form> 

</div>
 
<script type='text/javascript'>
function checkForm(){
                     if (jQuery('#exp_name').val()==""){alert('Please enter a popup name!'); return false;}
					 
					 if (jQuery('#exp_title').val()==""){alert('Please enter a title!'); return false;}
					 
					/* if (jQuery('#exp_description').val()==""){alert('Please enter a description!'); return false;} */
					  
					/* if (jQuery('#exp_image').val()==""){alert('Please upload a Image!'); return false;} */
					 
					/* if (jQuery('#exp_button_text').val()==""){alert('Please enter a button text!'); return false;} */
					 
					/* if (jQuery('#exp_button_url').val()==""){alert('Please enter a button url!'); return false;} */
					 
					 if (jQuery('#exp_button_color').val()==""){alert('Please enter a button background color!'); return false;}
					 
					 if (jQuery('#exp_button_text_color').val()==""){alert('Please enter a button text color!'); return false;}
					 
					 if (jQuery('#exp_border_color').val()==""){alert('Please enter a border color!'); return false;}
					 
					 if (jQuery('#exp_overlay_color').val()==""){alert('Please enter a overlay color!'); return false;}
					 
                     
                    } 
</script>