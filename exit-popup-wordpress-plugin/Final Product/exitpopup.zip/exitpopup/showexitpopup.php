<?php
 //include ('detectmobile.php')
 
 
 $user_agent = $_SERVER['HTTP_USER_AGENT'];

	// Create an array of known mobile user agents
	// This list is from the 21 October 2010 WURFL File.
	// Most mobile devices send a pretty standard string that can be covered by
	// one of these.  I believe I have found all the agents (as of the date above)
	// that do not and have included them below.  If you use this function, you 
	// should periodically check your list against the WURFL file, available at:
	// http://wurfl.sourceforge.net/


	$mobile_agents = Array(
		"240x320",
		"acer",
		"acoon",
		"acs-",
		"abacho",
		"ahong",
		"airness",
		"alcatel",
		"amoi",	
		"android",
		"anywhereyougo.com",
		"applewebkit/525",
		"applewebkit/532",
		"asus",
		"audio",
		"au-mic",
		"avantogo",
		"becker",
		"benq",
		"bilbo",
		"bird",
		"blackberry",
		"blazer",
		"bleu",
		"cdm-",
		"compal",
		"coolpad",
		"danger",
		"dbtel",
		"dopod",
		"elaine",
		"eric",
		"etouch",
		"fly " ,
		"fly_",
		"fly-",
		"go.web",
		"goodaccess",
		"gradiente",
		"grundig",
		"haier",
		"hedy",
		"hitachi",
		"htc",
		"huawei",
		"hutchison",
		"inno",
		"ipad",
		"ipaq",
		"ipod",
		"jbrowser",
		"kddi",
		"kgt",
		"kwc",
		"lenovo",
		"lg ",
		"lg2",
		"lg3",
		"lg4",
		"lg5",
		"lg7",
		"lg8",
		"lg9",
		"lg-",
		"lge-",
		"lge9",
		"longcos",
		"maemo",
		"mercator",
		"meridian",
		"micromax",
		"midp",
		"mini",
		"mitsu",
		"mmm",
		"mmp",
		"mobi",
		"mot-",
		"moto",
		"nec-",
		"netfront",
		"newgen",
		"nexian",
		"nf-browser",
		"nintendo",
		"nitro",
		"nokia",
		"nook",
		"novarra",
		"obigo",
		"palm",
		"panasonic",
		"pantech",
		"philips",
		"phone",
		"pg-",
		"playstation",
		"pocket",
		"pt-",
		"qc-",
		"qtek",
		"rover",
		"sagem",
		"sama",
		"samu",
		"sanyo",
		"samsung",
		"sch-",
		"scooter",
		"sec-",
		"sendo",
		"sgh-",
		"sharp",
		"siemens",
		"sie-",
		"softbank",
		"sony",
		"spice",
		"sprint",
		"spv",
		"symbian",
		"tablet",
		"talkabout",
		"tcl-",
		"teleca",
		"telit",
		"tianyu",
		"tim-",
		"toshiba",
		"tsm",
		"up.browser",
		"utec",
		"utstar",
		"verykool",
		"virgin",
		"vk-",
		"voda",
		"voxtel",
		"vx",
		"wap",
		"wellco",
		"wig browser",
		"wii",
		"windows ce",
		"wireless",
		"xda",
		"xde",
		"zte"
	);

	// Pre-set $is_mobile to false.

	$is_mobile = false;

	// Cycle through the list in $mobile_agents to see if any of them
	// appear in $user_agent.

	foreach ($mobile_agents as $device) {

		// Check each element in $mobile_agents to see if it appears in
		// $user_agent.  If it does, set $is_mobile to true.

		if (stristr($user_agent, $device)) {

			$is_mobile = true;

			// break out of the foreach, we don't need to test
			// any more once we get a true value.

			break;
		}
	}
 
 
 if (!$is_mobile){
 $CurURL='http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];  
 if (strpos($CurURL, 'www') === false && strpos($CurURL, 'wp-login') === false && strpos($CurURL, 'mailit') === false){
                            
                               
                               $Table = $wpdb->prefix . "exitpopup_tbl";
                               $Results1 = $wpdb->get_results( " SELECT * FROM $Table WHERE exp_id='$exp_id' ");

                               foreach ( $Results1 as $ro ){
                                                            $array = json_decode(json_encode($ro), True);
                                                            extract($array);
                                                           }
                               
                                                            
                               if ($_COOKIE['ndsbb']!="1"){
                              
                               echo "
                                     <div id='bb_ifContainer' style='position:fixed; top:0px; left:0px; width:100%; height:100%; margin-top:100%; z-index:99999; background-color:transparent;'>";
									  
									  
									  
 echo '<div id="exp_popup_main_bc" style="display:none;"><div class="exp_popup_overlay" style="position: fixed;top: 0;left: 0;right: 0;bottom: 0;background-color: '.$exp_overlay_color.';overflow-y: scroll;overflow-x: hidden;">
	<div class="exp_popup" style="position: absolute;width: 600px;top:50%;left:50%;box-shadow: 0 6px 8px rgba(0, 0, 0, 0.22);border:5px solid '.$exp_border_color.';transform:translate(-50%,-50%);-webkit-transform:translate(-50%,-50%);-moz-transform: translate(-50%,-50%);-ms-transform: translate(-50%,-50%);-o-transform: translate(-50%,-50%);font-family: \'Open Sans\', sans-serif;">
		<div class="close_popup" style="position: absolute;right: 10px;top: 10px;width: 25px;height: 25px;cursor: pointer;text-align: center;line-height: 25px;font-size: 16px;color: #fff;" onclick="deleteBounce();"><img src="'.$PGPath.'images/close-cross.png" alt=""></div>
		<div class="exp_popup_header" style="padding: 25px 20px;background-color:'.$exp_border_color.';">
			<h1 class="exp_header_title" style="font-size: 25px;text-transform: capitalize;text-align: center;line-height: 30px;margin: 10px 0; font-weight:bold;">'.$exp_title.'</h1>';
		if(!empty($exp_description)){
			echo '<p class="exp_discription" style="margin: 10px 0;font-size: 16px;color: #f5f5f5;text-align: center;padding: 0 20px;line-height: 22px;">'.$exp_description.'</p>';
		}
		echo '</div>
		<div class="exp_popup_body" style="text-align: center;padding: 35px 20px 0px; background-color: #fff;">';
		if(!empty($exp_image)){
		echo '<img src="'.$exp_image.'" alt="">';
		}
		echo '</div> 
		<div class="exp_popup_footer" style="text-align: center;padding:35px 20px 35px; background-color: #fff;">';
		if(!empty($exp_button_text)){
		echo '<a href="'.$exp_button_url.'" target="_blank" class="exp_modal_btn" style="display: inline-block; padding: 0px 35px; font-size: 15px;text-decoration: none;text-transform: capitalize;font-weight: 600;background-color: '.$exp_button_color.';color: '.$exp_button_text_color.'; height: 45px; line-height: 45px; text-align: center;box-shadow: none;">'.$exp_button_text.'</a>';
		}
		echo '</div>
	</div>
</div>
</div></div>';
		               echo "<div id='bbt1' style='position:fixed; top:0px; left:0px; width:100%; height:20px; background-color:transparent; z-index:99998;' onmouseover='doBounce();'></div>
                                     <div id='bbt2' style='position:fixed; top:20px; left:0px; width:100%; height:20px; background-color:transparent; z-index:99998;' onmouseleave='doSetBounce();'></div>
                                     
                                     <script type='text/javascript'>
                                     
                                     MU=0;
                                     
                                     function doBounce(){
                                                        console.log('--'+MU+'--');
                                                        if (MU==1){
                                                                   jQuery('#bb_ifContainer').animate({'margin-top': 0}, 750, function() {});
                                                                   jQuery.post('$PGPath"."doexitpopupstats.php', { B:'$exp_id' });
                                                                   jQuery.post('$PGPath"."setthecookie.php', { T:'$exitpopup_ResetTime' });
																   jQuery('#exp_popup_main_bc').show();
                                                                  }else{MU=0;}
																  
                                                        }
                                                        
                                     function doSetBounce(){
                                                            MU=1;
                                                            console.log('--'+MU+'--');
															
                                                           }                  
                                     
                                     function deleteBounce(){
                                                             jQuery('#bb_ifContainer').remove();
                                                             jQuery('#bbt1').remove();
                                                             jQuery('#bbt2').remove();
                                                            }
                                     
                                     
                                     
                                     //var H=jQuery(window).height();
                                     //jQuery('#bb_ifContainer').css('height', H);
                                     //jQuery('#bb_ifContainer').css('margin-top',H);
      
                                      
                                   
                                     </script>                   
                                    ";
                                   } 
                                  } 
                                 } 
?>