<?php
 require_once("../../../wp-load.php");
 global $wpdb;
 $PGPath=plugins_url()."/exitpopup/";
 include('checkvalid.php');
 
 $Table = $wpdb->prefix . "exitpopup_tbl";
 $B=$_GET['b'];
 $wpdb->delete( $Table, array( 'exp_id' => $B ) ); 
 
 header('location: '.admin_url().'admin.php?page=exitpopup');
?>  