<p></p>
<div class="exp_main_wrapper">
<div class="exp_header_wrapper">
	<div class="exp_logo_wrapper">
	 <a class="exp_main_logo" href="index.php?page=exitpopup"><img src="<?php echo $PGPath; ?>images/logo_new.png" border="0"></a>
	</div> 
	 
	<div class="exp_menu_wrapper">
		<ul>
			<li><a class="exp_menu_btn" href="admin.php?page=exitpopup">Home</a></li>
			<li><a class="exp_menu_btn" href="admin.php?page=exitpopup&s=s">Settings</a></li>
			<li><a class="exp_menu_btn" href="admin.php?page=exitpopup&s=h">Help</a></li>
		</ul>
	</div>
</div>

 <div class="exp_wrapper">

 <?php
  
  $s= $_GET['s'];
  if ($s==""){include('exit_popup.php');}
  if ($s=="s"){include('settings.php');} 
  if ($s=="h"){include('help_me.php');}
  if ($s=="nb"){include('newexitpopup.php');}
  if ($s=="e"){include('editexitpopup.php');}
  if ($s=="st"){include('stats.php');}
  
 ?>
 </div> 

 
</div>

