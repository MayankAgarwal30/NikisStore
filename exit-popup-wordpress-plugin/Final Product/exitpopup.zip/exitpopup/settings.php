<?php
 $exitpopup_ResetTime=get_option('exitpopup_ResetTime');
 $exitpopup_AddToEvery=get_option('exitpopup_AddToEvery');
?>

<div class="exp_create_section setting_popup">
<div class="exp_create_wrapper">
 <h2 class="exp_heading">Settings</h2>
</div>

<form class="exp_create_form" method="post" action="<?php echo $PGPath; ?>savesettings.php">
  <div class="exp_form_field">
   <label>Number of days before showing Exit popup </label>
   <input name="exitpopup_ResetTime" id="exitpopup_ResetTime" type="text" style="width:50px;" value="<?php echo stripslashes($exitpopup_ResetTime); ?>" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')">
  </div> 
  
  <div class="exp_form_field">
   <label>Add to entire site -</label>
    <select name="exitpopup_AddToEvery">
     <option value='0'>None</option>
      <?php
       $Table=$wpdb->prefix . "exitpopup_tbl";
       $Results1 = $wpdb->get_results( "SELECT * FROM $Table ");
       foreach ( $Results1 as $ro ){ 
                                     //print_r($ro);
                                     $array = json_decode(json_encode($ro), True);
                                     extract($array);                                   
                                     $exp_name=stripslashes($exp_name);
                                     
                                     echo "<option value='$exp_id' ";
                                     if ($exitpopup_AddToEvery==$exp_id){echo " selected='selected' ; ";}
                                     echo ">$exp_name</option>";
                                   }  
                                     
      ?>
    </select> 
  </div>
  
  <div class="exp_form_field">
   <div class="exp_btn_wrapper"><input type="submit" value="Save Settings"></div>
  </div>
</form>
</div>



