<?php
  $exitpopup_ResetTime=$_POST['T'];
  setcookie('ndsbb','1',time() + (86400 * $exitpopup_ResetTime),'/');
?>